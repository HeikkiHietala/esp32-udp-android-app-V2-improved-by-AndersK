package com.example.ESP32CAR

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import com.example.ESP32CAR.R.id.txtShowIP
import kotlinx.android.synthetic.main.activity_settings.*
import org.w3c.dom.Text


class Settings : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //var editEnterip =  mySettings.RemoteHost
        //var editEnterport= mySettings.RemotePort
        setContentView(R.layout.activity_settings)
        editEnterip.setText(intent.getStringExtra("ip"))
        editEnterport.setText(intent.getIntExtra("port", 0).toString())

        btnSetip.setOnClickListener {
            /*
            var finalIP =findViewById<EditText>(R.id.editEnterip)
            var textFromEditText = finalIP.text.toString() // access text this way
            mySettings.RemoteHost = textFromEditText.toString()
            var finalPort =findViewById<EditText>(R.id.editEnterport)
            var textfromEnterport = finalPort.text.toString().toInt()
            //finalPort = "1238"
            mySettings.RemotePort = textfromEnterport.toInt()

            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
             */

//            val resultIntent = Intent()
//            resultIntent.putExtra("ip", editEnterip.text.toString())
//            resultIntent.putExtra("port", editEnterport.text.toString().toString())
//
//            setResult(1, resultIntent)


            setResult(1, Intent().apply {
                putExtra("ip", editEnterip.text.toString())
                putExtra("port", editEnterport.text.toString().toInt())
                })

            finish()
        }
        btnCancelip.setOnClickListener {
            Log.d("HUDP", "cancel IP")
            setResult(2)
            finish()
            /*
            var editEnterip =  "null"
            var editEnterport = "null"
            myTargetIP = editEnterip
            myTargetPort = editEnterport
            val intent = Intent(this, MainActivity::class.java);
            intent.putExtra("myTargetIP", myTargetIP)
            intent.putExtra("myTargetPort", myTargetPort)
            startActivity(intent)
             */
        }
    }
}
