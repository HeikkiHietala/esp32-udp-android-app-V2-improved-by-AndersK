package com.example.ESP32CAR

import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.viewModels
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*
import java.lang.Exception

class Car {
    var speed: Int = 0
        set(value) {
            if (value < -10) field = -10
            else if (value > 10) field = 10
            else field = value
            }
    var direction: Int = 0
        set(value) {
            if (value < -5) field = -5
            else if (value > 5) field = 5
            else field = value
        }
    val udpMessage: String get() = "$speed,$direction"
    }

class MainViewModel : ViewModel() {
    val car = MutableLiveData<Car>().apply { value = Car() }
    val targetIP = MutableLiveData<String>().apply { value = "192.168.0.45" }
    val targetPort = MutableLiveData<Int>().apply { value = 63633 }
    }

/*
var mySpeed: Int = 0
var myDirection:Int = 0
var myTargetIP = "not set"
var myTargetPort = "not set"
var myUDP:String = ""

public class SoftOptions {
    var RemoteHost: String = "192.168.0.45"
    var RemotePort: Int = 63633

    constructor()
    init{}
}

// Global
val mySettings = SoftOptions()
*/

class MainActivity : AppCompatActivity() {
    val model: MainViewModel by viewModels()

    /*
    fun sendUDP(messageStr: String) {
        // Hack Prevent crash (sending should be done using an async task)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        try {
            //Open a port to send the package
            val socket = DatagramSocket()
            socket.broadcast = true
            val sendData = messageStr.toByteArray()
            val sendPacket = DatagramPacket(sendData, sendData.size, InetAddress.getByName(mySettings.RemoteHost), mySettings.RemotePort)
            socket.send(sendPacket)
        }            catch (e: Exception) {
            Log.w("HUDP", "sendUDP: $e")
        }

    }
    */

    private fun sendUDP(message: String) {
        // IO
        // Main
        // Default
        GlobalScope.launch(Dispatchers.IO) { // launch coroutine in the io thread
            try {
                val socket = DatagramSocket()
                socket.broadcast = true // why?
                val sendData = message.toByteArray()
                val sendPacket = DatagramPacket(
                    sendData,
                    sendData.size,
                    InetAddress.getByName(model.targetIP.value),
                    model.targetPort.value ?: 0
                )
                socket.send(sendPacket)
                runOnUiThread {
                    txtShowIP.text = "Done"
                    }
                }
            catch (e: Exception) {
                Log.e("HUDP", "sendUDP: $e", e)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //var intent = intent
        /*
        val IPtoshow = intent.getStringExtra("myTargetIP")
        val resultTv = this.findViewById<TextView>(R.id.txtShowIP)
        resultTv.text = "Target device IP is set as " + mySettings.RemoteHost
        val PortToShow = intent.getStringExtra("myTargetPort")
        val resultTvPort = this.findViewById<TextView>(R.id.txtShowPort)
        resultTvPort.text = "Target device port is set as " + mySettings.RemotePort
        */

        model.car.observeForever { car ->
            txtSpeed.text = "${car.speed}"
            txtDirection.text = "${car.direction}"
            sendUDP(car.udpMessage)
            }
        model.targetPort.observeForever {
            txtShowPort.text = "Target device port is set as $it"
            }
        model.targetIP.observeForever {
            txtShowIP.text = "Target device IP is set as $it"
            }

        btnIncrease.setOnClickListener {
            model.car.value = model.car.value?.apply {
                speed++
                }
            }

        btnDecrease.setOnClickListener {
            model.car.value = model.car.value?.apply {
                speed--
            }
        }

        btnStop.setOnClickListener {
            model.car.value = Car()
            }

        btnLeft.setOnClickListener {
            model.car.value = model.car.value?.apply {
                direction--
            }
        }

        btnCenter.setOnClickListener {
            model.car.value = model.car.value?.apply {
                direction = 0
            }
        }
        btnRight.setOnClickListener {
            model.car.value = model.car.value?.apply {
                direction++
            }
        }
        btnSettings.setOnClickListener {
            val intent = Intent(this, Settings::class.java);
            intent.putExtra("port", model.targetPort.value ?: 0)
            intent.putExtra("ip", model.targetIP.value)
            startActivityForResult(intent, 1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (resultCode) {
            1 -> {
                model.targetIP.value = data?.getStringExtra("ip") ?: "onknown"
                model.targetPort.value = data?.getIntExtra("port", 0)
                }
            }

        }

}



